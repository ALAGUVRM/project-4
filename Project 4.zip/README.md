
This project involves:
NumPy
Pandas
MatPlotlib
Seaborn and 
Python.

These are used to analyse a dataset. 



The dataset which i was choosed is the Titanic Dataset provided by Kaggle.
com
.

This repository contains:-
 copy of the dataset "titanic_data.csv"


HTML version of the report "Titanic Dataset Investigation.html"


iPython notebook - used to generate the report "Titanic Dataset Investigation.ipynb".



CREATOR
MS.ALAGAMMAI
Prusuing B.E Computer Science Engneering 
From Kgisl Institute of Technology
Contact : 9842878770
E-mail:alagammai1233@gmail.com